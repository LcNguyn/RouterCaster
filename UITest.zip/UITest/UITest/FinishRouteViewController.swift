//
//  FinishRouteViewController.swift
//  UITest
//
//  Created by tang quang an on 4/30/19.
//  Copyright © 2019 tang quang an. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import FBSDKLoginKit
import FBSDKShareKit

class FinishRouteViewController: UIViewController, UIScrollViewDelegate, GMSMapViewDelegate {

    @IBOutlet weak var routeImage: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var routeDistanceLb: UILabel!
    @IBOutlet weak var timeTravelledLb: UILabel!
    
    var myPath: GMSPath?
    var myPolyline: GMSPolyline = GMSPolyline()
    var startMarker: GMSMarker?
    var endMarker: GMSMarker?
    var timeTravelled: TimeInterval?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.backgroundColor = UIColor.init(displayP3Red: 0, green: 0, blue: 0, alpha: 0.1)
        
        
        // Display data
        routeDistanceLb.text = String((Double((GMSGeometryLength(myPath!)) / 1000) / 1.609).roundToDecimal(2))

        timeTravelledLb.text = timeTravelled!.stringFromTimeInterval()
        
//        routeDistanceLb.text = "350"
//        timeTravelledLb.text = "00:00:36"
//
//        // OK version
//        var staticMapUrl: String = "https://maps.googleapis.com/maps/api/staticmap?size=\(Int(routeImage.frame.width))x\(Int(routeImage.frame.height))&path=weight:3|color:red|enc:s`seFdnbjVZEAQAa@De@DQX_@vBqClA{AFKTNnAbBbDnExAtBqD~EiBbCe@l@IDKBMCoBR}@Ha@Lm@RgBPWwDk@cJ[{E&key=AIzaSyCMYfiszedRS_hcUjJUyRCx9QPsaR2zUPQ"
        
        let staticMapUrl: String = "https://maps.googleapis.com/maps/api/staticmap?size=\(Int(routeImage.frame.width))x\(Int(routeImage.frame.height))&markers=color:green|label:S|\(Double((startMarker?.position.latitude)!)),\(Double((startMarker?.position.longitude)!))&markers=color:red|label:E|\(Double((endMarker?.position.latitude)!)),\(Double((endMarker?.position.longitude)!))&path=weight:3|color:red|enc:\(self.myPath!.encodedPath())&key=AIzaSyCMYfiszedRS_hcUjJUyRCx9QPsaR2zUPQ"

//        print(self.myPolyline.path?.encodedPath())
//        print(routeImage.frame.width)
        
        let imageSession = URLSession(configuration: .ephemeral)
        if let url = NSURL(string: (staticMapUrl.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed))!) {
            
            print("Yessssssssssss")
            let task = imageSession.dataTask(with: url as URL) { (imageData, _, _) in
                guard let imageData = imageData, let image = UIImage(data: imageData) else {return}
                
                DispatchQueue.main.async {
                    
                    let newImage = self.textToImage(drawText: "Route distance: \(self.routeDistanceLb.text!)\nTime Travelled: \(self.timeTravelledLb.text!)", inImage: image, atPoint: CGPoint(x: 0, y: 0))
                    
                    
                    self.routeImage.image = newImage
    //                routeImage.frame = CGRect(x: 0, y: 50, width: 200, height: 200)
//                    self.routeImage.contentMode = UIView.ContentMode.scaleAspectFit
                    //                    imageView.sizeToFit()
                }
            }
            task.resume()
        }
        self.showAnimate()
    }
    
    //    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        
//        self.view.frame.origin.x += self.view.frame.size.width
//    }
    
    @IBAction func didCloseView(_ sender: Any) {
        
        weak var pvc = (self.parent as! TrackRouteViewController)
        self.dismiss(animated: true) {
            pvc?.dismiss(animated: true, completion: {
                
            })
        }
        
    }
    @IBAction func didPressShare(_ sender: Any) {
        var content = FBSDKShareLinkContent()
        content.contentURL = URL(string: "https://www.google.com")
        
        let photo = FBSDKSharePhoto()
        photo.image = #imageLiteral(resourceName: "Rectangle")
        photo.isUserGenerated = true
        photo.caption = "Testing testing"
        
        var dialog = FBSDKShareDialog()
        
        let newContent = FBSDKSharePhotoContent()
        
        //        newContent.contentURL =  URL(string: "https://www.google.com")
        //        newContent.contentURL = URL(string: "https://www.google.com")
        newContent.photos = [photo]
        dialog.fromViewController = self
        dialog.shareContent = newContent
        dialog.mode = FBSDKShareDialogMode.feedWeb
        dialog.show()
    }
    @IBAction func didSaveRoute(_ sender: Any) {
        print("Yes")
        scrollView.setContentOffset(CGPoint(x: 434, y: 0), animated: true)
    }
    
    func showAnimate() {
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        self.view.alpha = 0.0
        UIView.animate(withDuration: 0.25) {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
//    func getRouteImage() {
//
//        let myMapView = GMSMapView()
//        myMapView.delegate = self
//
//        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//        myView.backgroundColor = .black
//        self.routeImage.image = myView.asImage()
//        self.routeImage.sizeToFit()
//    }
    
    func textToImage(drawText text: String, inImage image: UIImage, atPoint point: CGPoint) -> UIImage {
//        let textColor = UIColor.black
//        let textFont = UIFont(name: "Avenir-Medium", size: 20)!
//
//        let scale = UIScreen.main.scale
//        UIGraphicsBeginImageContextWithOptions(image.size, false, scale)
//
//        let textFontAttributes = [
//            NSAttributedString.Key.font: textFont,
//            NSAttributedString.Key.foregroundColor: textColor,
//            ] as [NSAttributedString.Key : Any]
//        image.draw(in: CGRect(origin: CGPoint.zero, size: image.size))
//
//        let rect = CGRect(origin: point, size: image.size)
////        UIColor.white.setFill()
////        UIRectFill(rect)
//
//        text.draw(in: rect, withAttributes: textFontAttributes)
//
//        let newImage = UIGraphicsGetImageFromCurrentImageContext()
//        UIGraphicsEndImageContext()
//
//        // Fill rectangle
//        let imageSize = image.size
//        let scale: CGFloat = 0
//        UIGraphicsBeginImageContextWithOptions(imageSize, false, scale)
//
//        image.draw(at: CGPoint.zero)
//
//        let rectangle = CGRect(x: 0, y: (imageSize.height/2) - 30, width: imageSize.width, height: 60)
//
//        UIColor.black.setFill()
//        UIRectFill(rectangle)
//
//        let newImage = UIGraphicsGetImageFromCurrentImageContext()
//        UIGraphicsEndImageContext()
        
        // New
        let textColor = UIColor.black
        let textFont = UIFont(name: "Avenir-Medium", size: 20)!
        let imageSize = image.size
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(imageSize, false, scale)
        
        image.draw(at: CGPoint.zero)
        let textFontAttributes = [
            NSAttributedString.Key.font: textFont,
            NSAttributedString.Key.foregroundColor: textColor,
            ] as [NSAttributedString.Key : Any]
        
        let rectangle = CGRect(x: 0, y: 0, width: NSString(string: text).size(withAttributes: textFontAttributes).width, height: NSString(string: text).size(withAttributes: textFontAttributes).height)
        UIColor.white.setFill()
        UIRectFill(rectangle)
        
        text.draw(in: rectangle, withAttributes: textFontAttributes)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }

}

extension Double {
    func roundToDecimal(_ fractionDigits: Int) -> Double {
        let multiplier = pow(10, Double(fractionDigits))
        return Darwin.round(self * multiplier) / multiplier
    }
}

extension TimeInterval{
    
    func stringFromTimeInterval() -> String {
        
        let time = NSInteger(self)
        
        let seconds = time % 60
        let minutes = (time / 60) % 60
        let hours = (time / 3600)
        
        return String(format: "%0.2d:%0.2d:%0.2d",hours,minutes,seconds)
    }
}

